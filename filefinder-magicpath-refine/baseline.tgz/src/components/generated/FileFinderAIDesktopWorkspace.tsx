import React, { useEffect, useState } from "react";
import "./FileFinderAIDesktopWorkspace.css";
type Route = "Home" | "Search" | "AI Assistant" | "Organization" | "Settings";
const routes: {
  name: Route;
  icon: string;
}[] = [{
  name: "Home",
  icon: "⌂"
}, {
  name: "Search",
  icon: "⌕"
}, {
  name: "AI Assistant",
  icon: "✳"
}, {
  name: "Organization",
  icon: "▱"
}, {
  name: "Settings",
  icon: "⚙"
}];
const sampleFiles = [{
  name: "graduation_certificate.pdf",
  kind: "PDF",
  size: "2.4 MB",
  path: "Documents / College",
  match: "94%",
  tint: "violet"
}, {
  name: "degree_scan_final.jpg",
  kind: "IMAGE",
  size: "4.8 MB",
  path: "Pictures / Scans",
  match: "87%",
  tint: "blue"
}, {
  name: "course_completion.pdf",
  kind: "PDF",
  size: "1.1 MB",
  path: "Documents / Courses",
  match: "73%",
  tint: "mint"
}];
const Icon = ({
  children
}: {
  children: React.ReactNode;
}) => <span className="icon" aria-hidden="true">{children}</span>;
const FileMark = ({
  kind
}: {
  kind: string;
}) => <span className={"filemark " + kind.toLowerCase()}>{kind === "PDF" ? "PDF" : "▧"}</span>;
export const FileFinderAIDesktopWorkspace = () => {
  const [route, setRoute] = useState<Route>("Home");
  const [query, setQuery] = useState("");
  const [searchState, setSearchState] = useState<"idle" | "searching" | "results">("idle");
  const [modal, setModal] = useState<"preview" | "index" | "analysis" | null>(null);
  const [progress, setProgress] = useState(12);
  const [analysisDone, setAnalysisDone] = useState(false);
  const [approved, setApproved] = useState(false);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState(false);
  const [toast, setToast] = useState("");
  useEffect(() => {
    if (modal !== "index") return;
    const timer = window.setInterval(() => setProgress(p => Math.min(100, p + 4)), 250);
    return () => window.clearInterval(timer);
  }, [modal]);
  useEffect(() => {
    if (progress !== 100 || modal !== "index") return;
    const timer = window.setTimeout(() => {
      setModal(null);
      note("Your files are ready to search.");
    }, 500);
    return () => window.clearTimeout(timer);
  }, [progress, modal]);
  const note = (value: string) => {
    setToast(value);
    window.setTimeout(() => setToast(""), 2300);
  };
  const search = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setSearchState("searching");
    window.setTimeout(() => {
      setRoute("Search");
      setSearchState("results");
    }, 1000);
  };
  const startIndex = () => {
    setProgress(12);
    setModal("index");
  };
  const startAnalysis = () => {
    setAnalysisDone(false);
    setModal("analysis");
    window.setTimeout(() => setAnalysisDone(true), 1500);
  };
  const go = (next: Route) => {
    setRoute(next);
    if (next === "Search") {
      setQuery("");
      setSearchState("idle");
    }
  };
  return <div className="ff-app">
    <aside className="ff-rail">
      <div className="ff-brand"><span className="brand-icon"><i /><i /><i /></span><span><b>FileFinder <em>AI</em></b><small>Your files, understood.</small></span></div>
      <div className="nav-caption">WORKSPACE</div>
      <nav>{routes.map(item => <button key={item.name} className={"nav-link " + (route === item.name ? "selected" : "")} onClick={() => go(item.name)}><Icon>{item.icon}</Icon><span>{item.name}</span>{item.name === "Organization" && <small>3</small>}</button>)}</nav>
      <div className="rail-foot">
        <div className="index-status"><div><span className="pulse-dot" /><strong>Indexed locally</strong><span className="lock">⌑</span></div><p><b>4</b> folders <i /> <b>1,248</b> files</p><div className="tiny-progress"><i /></div><small>Private by design</small></div>
        <div className="privacy-link">◇ <span>Your files stay on this device</span></div>
      </div>
    </aside>
    <main className="ff-main">
      <header className="ff-top"><div className="crumb">FILEFINDER AI <span>/</span> <b>{route.toUpperCase()}</b></div><div className="top-actions"><span className="online"><i /> Indexed locally</span><button onClick={() => note("You're all caught up.")} aria-label="Notifications">◌<sup /></button></div></header>
      <div className="ff-content">
        {route === "Home" && <section>
          <div className="greeting"><div><small>TUESDAY, OCTOBER 7</small><p>Good evening, Shamli <em>✦</em></p></div><button className="link-button" onClick={() => go("Search")}>View all files <b>→</b></button></div>
          <div className="hero-card">
            <div className="hero-content"><div className="hero-label"><span>✳</span> YOUR PERSONAL FILE INTELLIGENCE</div><h1>Find <em>anything.</em></h1><h2>Your files, understood.</h2><p>Tell FileFinder AI what you’re looking for.<br />We’ll find the right file, wherever it lives.</p>
              <form className="hero-search" onSubmit={search}><span>⌕</span><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Find my graduation certificate..." aria-label="Search files" /><label>✳ AI search</label><button aria-label="Search" type="submit">→</button></form>
              <div className="try-line">Try {["my resume", "recent PDFs", "college certificates"].map(t => <button key={t} onClick={() => setQuery(t)}>{t}</button>)}</div>
            </div><div className="hero-orb"><div className="orb-ring ring-a" /><div className="orb-ring ring-b" /><div className="orb-core">✳</div><span>✦</span><small>LOCAL-FIRST INTELLIGENCE</small></div>
            {searchState === "searching" && <div className="hero-thinking"><span className="think-orb">✳</span><div><b>Understanding your request</b><small>Searching across 1,248 indexed files</small></div></div>}
          </div>
          <div className="section-line"><span>YOUR LIBRARY <i>Updated just now</i></span><button onClick={() => go("Settings")}>Manage folders →</button></div>
          <div className="stats">{[["▦", "TOTAL FILES", "1,248", "Across your library", ""], ["▧", "IMAGES", "342", "Visual memories", "blue"], ["PDF", "PDFS", "86", "Ready to understand", "violet"], ["▱", "FOLDERS", "4", "On this device", "green"]].map(x => <div className="stat" key={x[1]}><span className={"stat-icon " + x[4]}>{x[0]}</span><small>{x[1]}</small><b>{x[2]}</b><label>{x[3]}</label></div>)}</div>
          <div className="section-line quick-heading"><span>QUICK ACTIONS</span></div>
          <div className="actions">
            <button onClick={() => go("Search")}><span className="action-icon">⌕</span><span><b>Search files</b><small>Keywords or natural language</small></span><i>→</i></button>
            <button className="action-feature" onClick={() => go("AI Assistant")}><span className="action-icon">✳</span><span><b>Ask your files</b><small>Answers grounded in your library</small></span><i>→</i></button>
            <button onClick={startIndex}><span className="action-icon">＋</span><span><b>Add a folder</b><small>Expand your local index</small></span><i>→</i></button>
            <button onClick={startAnalysis}><span className="action-icon">✧</span><span><b>Analyze files</b><small>Understand PDFs and images</small></span><i>→</i></button>
          </div>
          <div className="home-lower">
            <section className="recent-card"><div className="card-head"><div><small>RECENTLY DISCOVERED</small><h3>Back in focus</h3></div><button onClick={() => go("Search")}>All files →</button></div>
              {[["graduation_certificate.pdf", "Documents / College", "Yesterday", "PDF"], ["passport_photo.png", "Pictures / Personal", "2 days ago", "IMAGE"], ["resume_2025.pdf", "Documents / Career", "Last week", "PDF"]].map(x => <button className="recent-row" key={x[0]} onClick={() => setModal("preview")}><FileMark kind={x[3]} /><span><b>{x[0]}</b><small>{x[1]}</small></span><time>{x[2]}</time><i>···</i></button>)}
            </section>
            <aside className="insight-card"><div className="insight-top"><span>✳</span> AI INSIGHT <b>NEW</b></div><h3>A pattern worth finding.</h3><p>8 documents in your library look like certificates. They’re spread across 3 folders.</p><button onClick={() => {
                setQuery("certificates");
                setRoute("Search");
                setSearchState("results");
              }}>Explore documents →</button><div className="insight-rings" /></aside>
          </div>
        </section>}

        {route === "Search" && <section className="route-view">
          <div className="route-title"><div><small>LOCAL FILE DISCOVERY</small><h1>Search your files</h1><p>Search by name, type, folder, or describe what you remember.</p></div><span className="privacy-chip">◇ Searches stay on this device</span></div>
          <form className="route-search" onSubmit={search}><span>⌕</span><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Describe a file or search by name..." aria-label="Search your files" /><label>✳ AI search</label><button type="submit">→</button></form>
          <div className="filters"><div><button className="active-filter">✳ AI-understood</button><button onClick={() => note("Keyword search matches file names and metadata.")}>⌕ Keyword</button></div><button onClick={() => note("Filter by file type, folder, or modified date.")}>☷ Filters <b>2</b></button><button onClick={() => note("Sorted by best match.")}>Best match⌄</button></div>
          {searchState === "searching" ? <div className="search-wait"><span className="think-orb">✳</span><h3>Understanding your request...</h3><p>Looking through your selected folders</p><div className="skeleton"><i /><i /><i /></div></div> : searchState === "results" ? <div className="results"><div className="results-heading"><div><b>I found 2 likely matches.</b><p>Ranked by how closely each file matches your request.</p></div><span>✳ AI UNDERSTOOD</span></div>{sampleFiles.slice(0, 2).map(file => <article className="result-card" key={file.name}><div className={"result-preview " + file.tint}><div className="paper-preview"><i className="seal">✦</i><b>{file.kind === "PDF" ? "CERTIFICATE" : "UNIVERSITY"}</b><span /><span /><span /></div></div><div className="result-info"><div className="result-name"><h3>{file.name}</h3><span>✳ {file.match} match</span></div><div className="metadata">{file.kind} <i /> {file.size}<i /> {file.path}</div><p className="match-reason">✳ <span>Content appears consistent with a graduation certificate.</span></p><div className="result-actions"><button className="secondary" onClick={() => setModal("preview")}>Preview</button><button onClick={() => note("Opening file in its default application.")}>↗ Open file</button><button onClick={() => note("Opening containing folder.")}>▱ Open folder</button></div></div></article>)}</div> : <div className="search-start"><div>✳</div><h2>What are you looking for?</h2><p>Describe the file you remember. FileFinder searches names, folders, dates, and understood content.</p>{["Find my certificates", "Show recent PDFs", "Where is my resume?"].map(x => <button key={x} onClick={() => setQuery(x)}>{x} →</button>)}</div>}
        </section>}

        {route === "AI Assistant" && <section className="route-view"><div className="route-title"><div><small>GROUNDED IN YOUR LOCAL INDEX</small><h1>Your files, in context.</h1><p>Ask about your indexed files. Answers include the files behind them.</p></div><span className="privacy-chip"><i /> Ready</span></div>
          <div className="assistant-layout"><aside className="suggestions"><small>START WITH A QUESTION</small>{["Find my certificates", "Show recent PDFs", "Where is my resume?", "Photos in Documents"].map((x, i) => <button key={x} onClick={() => {
                setQuestion(x);
                setAnswer(true);
              }}><i>0{i + 1}</i>{x}<span>→</span></button>)}<p>◇ Answers are grounded in your selected folders and indexed file details.</p></aside>
            <div className="chat-card"><header><span className="chat-logo">✳</span><span><b>FileFinder Assistant</b><small>Knows your local library</small></span><button onClick={() => {
                  setAnswer(false);
                  setQuestion("");
                }}>↻</button></header><div className="chat-body">{!answer && <div className="chat-welcome"><span>✳</span><h2>A better way to find what you remember.</h2><p>Ask a question about your files and I’ll bring the most relevant ones into view.</p></div>}{answer && <><div className="user-message">{question}</div><div className="ai-answer"><b>✳ &nbsp;I found 2 likely matches.</b><p>These files appear to be education credentials based on their names and indexed content.</p>{sampleFiles.slice(0, 2).map(f => <button key={f.name} onClick={() => setModal("preview")}><FileMark kind={f.kind} /><span><b>{f.name}</b><small>{f.path}</small></span>→</button>)}</div></>}</div><form className="chat-input" onSubmit={e => {
                e.preventDefault();
                if (question.trim()) setAnswer(true);
              }}><input value={question} onChange={e => setQuestion(e.target.value)} placeholder="Ask about a file or folder..." /><button>↑</button></form></div>
          </div>
        </section>}

        {route === "Organization" && <section className="route-view"><div className="route-title"><div><small>A TIDIER LIBRARY, ON YOUR TERMS</small><h1>Organize with confidence.</h1><p>Review AI suggestions before anything changes.</p></div><span className="privacy-chip">● 3 suggestions</span></div>
          {approved ? <div className="approved"><span>✓</span><h2>Suggestion approved</h2><p>Your organization choice has been recorded. Files only move after your confirmation.</p><button className="secondary" onClick={() => setApproved(false)}>Back to suggestions</button></div> : <article className="org-card"><div className="org-caption"><span>✳</span><div><small>AI SUGGESTION</small><p>Based on file names and content</p></div><button>···</button></div><h2>These files look like certificates.</h2><p className="org-copy">They share credential details and may be easier to find together.</p>{sampleFiles.map(f => <div className="org-row" key={f.name}><FileMark kind={f.kind} /><span><b>{f.name}</b><small>{f.path}</small></span><em>✓ Reviewed</em></div>)}<div className="destination"><div><small>SUGGESTED DESTINATION</small><p>▱ &nbsp;Documents &nbsp;›&nbsp; Certificates</p></div><button onClick={() => note("Choose a destination folder.")}>Change destination</button></div><footer><span>◇ Nothing moves without your approval.</span><div><button onClick={() => note("Suggestion rejected.")}>Reject</button><button className="primary" onClick={() => setApproved(true)}>✓ Approve suggestion</button></div></footer></article>}
        </section>}

        {route === "Settings" && <section className="route-view"><div className="route-title"><div><small>YOUR WORKSPACE, YOUR RULES</small><h1>Settings</h1><p>Manage AI, indexed locations, and privacy.</p></div></div><div className="settings-layout"><div className="settings-main">
          <section className="settings-card"><header><span>✳</span><div><b>AI configuration</b><small>Control how FileFinder understands your files.</small></div><em>● CONFIGURED</em></header><div className="setting-row"><span><b>AI provider</b><small>Connected securely</small></span><strong>OpenAI &nbsp;›</strong></div><div className="setting-row"><span><b>API key</b><small>Your key is stored securely and never shown.</small></span><strong className="masked">•••••••••••••• <i>◇</i></strong></div><div className="setting-row"><span><b>Analyze supported files</b><small>Images and PDFs in indexed folders</small></span><button className="toggle on" onClick={e => e.currentTarget.classList.toggle("on")}><i /></button></div></section>
          <section className="settings-card"><header><span className="folder-settings">▱</span><div><b>Indexed folders</b><small>Only folders you choose are scanned.</small></div><button className="secondary add-folder" onClick={startIndex}>＋ Add folder</button></header>{["Documents", "Pictures", "Desktop", "College"].map((f, i) => <div className="folder-setting" key={f}><span>▱</span><div><b>{f}</b><small>{["C:/Users/Shamli/Documents", "C:/Users/Shamli/Pictures", "C:/Users/Shamli/Desktop", "D:/College"][i]}</small></div><em>{[562, 342, 198, 146][i]} files</em><button onClick={startIndex}>↻</button></div>)}</section>
        </div><aside className="settings-side"><div className="privacy-card"><span>◇</span><small>PRIVATE BY DESIGN</small><h3>Your files stay yours.</h3><p>FileFinder scans only folders you select. Your local index stays on this device.</p><button onClick={() => note("Your selected files remain on this device.")}>Privacy details →</button></div><div className="about-card"><small>APPLICATION</small><p>Version <b>1.0.0</b></p><p>Local index <b>1,248 files</b></p><p>Last indexed <b>Today, 6:42 PM</b></p></div></aside></div></section>}
      </div>
    </main>

    {modal && <div className="overlay" onMouseDown={e => {
      if (e.target === e.currentTarget) setModal(null);
    }}>
      {modal === "preview" && <section className="preview-modal" role="dialog" aria-modal="true"><header><span><FileMark kind="PDF" /><b>graduation_certificate.pdf<small>PDF document · 2.4 MB</small></b></span><button onClick={() => setModal(null)}>×</button></header><div className="preview-body"><div className="document-stage"><div className="document"><div>U</div><small>UNIVERSITY OF EXAMPLE</small><h2>Certificate<br />of Graduation</h2><i /><p>This certifies that</p><b>Alexandra Morgan</b><p>has fulfilled the requirements for</p><strong>Bachelor of Arts</strong><footer>✦</footer></div></div><aside><small>FILE DETAILS</small><h3>graduation_<br />certificate.pdf</h3><span className="ai-badge">✳ AI understood</span>{[["Type", "PDF document"], ["Size", "2.4 MB"], ["Location", "Documents / College"], ["Modified", "Yesterday, 3:18 PM"]].map(x => <p className="detail" key={x[0]}><small>{x[0]}</small><b>{x[1]}</b></p>)}<div className="explanation">✳ <span>Content appears consistent with a graduation certificate.</span></div><button className="primary" onClick={() => note("Opening file in its default application.")}>↗ Open file</button><button className="secondary" onClick={() => note("Opening containing folder.")}>▱ Open folder</button></aside></div></section>}
      {modal === "index" && <section className="progress-modal" role="dialog" aria-modal="true"><button className="modal-close" onClick={() => setModal(null)}>×</button><div className="index-illustration"><span>▱</span><i /><i /></div><small>LOCAL INDEXING</small><h2>Preparing your files.</h2><p>Scanning your selected folder and its subfolders.</p><div className="progress-text"><b>{Math.round(progress * 12.48).toLocaleString()}</b> of 1,248 files <strong>{progress}%</strong></div><div className="progress-bar"><i style={{
            width: progress + "%"
          }} /></div><div className="scanning"><span>▱ &nbsp;Documents</span><small>Including subfolders</small></div><div className="safe-note">◇ &nbsp;Your files aren’t moved or changed.</div></section>}
      {modal === "analysis" && <section className="progress-modal" role="dialog" aria-modal="true"><button className="modal-close" onClick={() => setModal(null)}>×</button><div className="analysis-mark">{analysisDone ? "✓" : "✳"}</div><small>AI FILE UNDERSTANDING</small><h2>{analysisDone ? "Your files are understood." : "Understanding your files."}</h2><p>{analysisDone ? "Supported PDFs and images have been analyzed." : "Finding useful details in supported PDFs and images."}</p><div className="analysis-file"><FileMark kind="PDF" /><span><b>graduation_certificate.pdf</b><small>{analysisDone ? "Analysis complete" : "Extracting document details..."}</small></span><i>{analysisDone ? "✓" : "•••"}</i></div><div className="progress-bar"><i style={{
            width: analysisDone ? "100%" : "68%"
          }} /></div><button className="primary done-button" onClick={() => setModal(null)}>{analysisDone ? "Done" : "Continue in background"} →</button></section>}
    </div>}
    {toast && <div className="toast">✓ &nbsp;{toast}</div>}
    <div className="preview-tag"><i /> INTERACTIVE DESIGN PREVIEW</div>
  </div>;
};